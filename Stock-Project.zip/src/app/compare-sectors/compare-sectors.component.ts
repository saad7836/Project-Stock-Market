import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-compare-sectors',
  templateUrl: './compare-sectors.component.html',
  styleUrls: ['./compare-sectors.component.css']
})

export class CompareSectorsComponent implements OnInit {

  constructor(private router:Router) { }

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels = ['june', 'july', 'august', 'sept', 'nov', 'dec'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [
    {data: [35, 45, 61, 71, 66, 75,80], label: 'Cts'},
    {data: [18, 88, 30, 29, 46, 47, 60], label: 'Tcs'}
  ];
  ngOnInit() {
  }
  ons(){
    this.router.navigate(['/']);
  }

}

