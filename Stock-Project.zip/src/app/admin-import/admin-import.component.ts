import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload';
import { Router } from '@angular/router';
import { ExcelModel } from 'src/entity/ExcelModel';
import { HttpResponse } from '@angular/common/http';
import { ExcelResponseModel } from 'src/entity/ExcelResponseModel';
import { UploadFileService } from '../upload-file.service';

const UploadURL = 'http://localhost:8102/import';

@Component({
  selector: 'app-admin-import',
  templateUrl: './admin-import.component.html',
  styleUrls: ['./admin-import.component.css']
})
export class AdminImportComponent implements OnInit {

  currentFileUpload: File;
  selectedFiles: FileList;
  excelDetails:ExcelModel[];

  excelsummary: ExcelResponseModel[];
  excelSumary1:ExcelResponseModel;

  constructor(private service:UploadFileService,private router: Router) { }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 


  ngOnInit(): void {
    this.service.getAllDetails().subscribe(data => {
    this.excelDetails = data.body;
    console.log(data.body) 
});

//-------------------------------------------------for summary------------------------------------

  this.service.getAllDetails1().subscribe(data => {
  this.excelSumary1 = data.body;
  console.log(data.body) 
});


//---------------------------------------------------summary------------------------------------------


  }
  
  // alert("done");
    //this.router.navigate(['/app-company-create']);
    upload() {
      this.currentFileUpload = this.selectedFiles.item(0);
      this.service.pushFileToStorage(this.currentFileUpload).subscribe(event => {
       if (event instanceof HttpResponse) {
          console.log('File is completely uploaded!');
        }
      });
      this.selectedFiles = undefined;
    }

}




