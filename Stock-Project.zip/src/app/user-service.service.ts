
import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from 'src/entity/UserModel';

type EntityResponseType = HttpResponse<UserModel[]>;

@Injectable({
  providedIn: 'root'
})
export class UserService {  

  constructor(private http:HttpClient) { }

  getAllUsers():Observable<EntityResponseType>{
        return this.http.get<UserModel[]>("http://localhost:8014/microservice5/users", {observe: 'response'});
  }

  saveUser(userModel:UserModel){
       return this.http.post<UserModel>("http://localhost:8014/microservice5/user", userModel, {observe: 'response'});
  }

}
