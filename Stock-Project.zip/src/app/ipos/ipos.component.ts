import { Component, OnInit } from '@angular/core';
import { IpoModel } from 'src/entity/IpoModel';
import { IpoService } from '../ipo.service';

  @Component({
    selector: 'app-ipos',
    templateUrl: './ipos.component.html',
    styleUrls: ['./ipos.component.css']
  })

  export class IPOsComponent implements OnInit {
    ipo:IpoModel[];
      constructor(private service:IpoService) { }
  
      ngOnInit(): void {
    this.service.getAll().subscribe(data =>{
    this.ipo=data.body;
  
    });
      }

}


  
