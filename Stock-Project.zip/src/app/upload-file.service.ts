import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExcelModel } from 'src/entity/ExcelModel';
import { ExcelResponseModel } from 'src/entity/ExcelResponseModel';

type EntityResponseType = HttpResponse<ExcelModel[]>;
type EntityResponseType1 = HttpResponse<ExcelResponseModel>;

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  constructor(private http:HttpClient) { }
  getAllDetails():Observable<EntityResponseType>{
    return this.http.get<ExcelModel[]>("http://localhost:8014/microservice4/stockData", {observe: 'response'});
}

//---------------------------------------------------------summary------------------------------------------------

getAllDetails1():Observable<EntityResponseType1>{
  return this.http.get<ExcelResponseModel>("http://localhost:8014/microservice4/summary", {observe: 'response'});
}


//----------------------------------------------------------summary------------------------------------------------------

pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
  const formdata: FormData = new FormData();
  formdata.append('file', file);
  const req = new HttpRequest('POST', "http://localhost:8014/microservice4/import", formdata,{
    reportProgress: true,
    responseType: 'text'
  }
  );
  return this.http.request(req);
}

}