import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UlandingComponent } from './ulanding/ulanding.component';
import { AlandingComponent } from './alanding/alanding.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminImportComponent } from './admin-import/admin-import.component';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { AddNewCompanyComponent } from './add-new-company/add-new-company.component';
import { IPOsComponent } from './ipos/ipos.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { CompareSectorsComponent } from './compare-sectors/compare-sectors.component';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { AddExchangeComponent } from './add-exchange/add-exchange.component';
import { AddNewIpoComponent } from './add-new-ipo/add-new-ipo.component';
import { CompareComponent } from './compare/compare.component';
import { CompareSecComponent } from './compare-sec/compare-sec.component';
import { SummaryDataComponent } from './summary-data/summary-data.component';


const routes: Routes = [
{path:'',component:LoginComponent},
{path:'admin',component:AlandingComponent},
{path:'user',component:UlandingComponent},
{path:'register',component:SignUpComponent},
{path:'import_d',component:AdminImportComponent},
{path:'manage_c',component:ManageCompanyComponent},
{path:'login',component:LoginComponent},
{path:'addcompany',component:AddNewCompanyComponent},
{path:'exchange',component:AddExchangeComponent},
{path:'ipo',component:IPOsComponent},
{path:'addstockexchange',component:ManageExchangeComponent},
{path:'addIpo',component:AddNewIpoComponent},
{path:'compare_c',component:CompareCompanyComponent},
{path:'compare_s',component:CompareSectorsComponent},
{path:'compare',component:CompareCompanyComponent},
{path:'compares',component:CompareComponent},
{path:'comparesec',component:CompareSecComponent},
{path:'app-summary-data',component:SummaryDataComponent}





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
