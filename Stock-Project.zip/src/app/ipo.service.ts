import { Injectable } from '@angular/core';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IpoModel } from 'src/entity/IpoModel';
type EntityResponseType = HttpResponse<IpoModel[]>
@Injectable({
  providedIn: 'root'
})
export class IpoService {

  constructor(private http: HttpClient) { }
  getAll(): Observable<EntityResponseType> {

    return this.http.get<IpoModel[]>("http://localhost:8014/microservice3/ipos", { observe: 'response' });
  }
  saveIpo(data: IpoModel) {
    return this.http.post<IpoModel>("http://localhost:8014/microservice3/ipo", data, { observe: 'response' });

  }
}
