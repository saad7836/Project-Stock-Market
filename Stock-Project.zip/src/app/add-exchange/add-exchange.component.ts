import { Component, OnInit } from '@angular/core';
import { StockexchangeserviceService } from '../stockexchangeservice.service';
import { ExchangeModel } from 'src/entity/ExchangeModel';
@Component({
  selector: 'app-add-exchange',
  templateUrl: './add-exchange.component.html',
  styleUrls: ['./add-exchange.component.css']
})


export class AddExchangeComponent implements OnInit {

  stocks:ExchangeModel[];
  stock:ExchangeModel[];

  constructor(private service:StockexchangeserviceService) { }

    ngOnInit(): void {
      this.service.getAllExchange().subscribe(data => {
           this.stocks = data.body;
           console.log(data.body)
      });

      // this.service.saveStockexchange(this.stock).subscribe(data =>{
      //    console.log(data.body);
      // });
      
  }

}


