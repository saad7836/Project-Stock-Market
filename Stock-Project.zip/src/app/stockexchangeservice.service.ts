import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExchangeModel } from 'src/entity/ExchangeModel';

type EntityResponseType = HttpResponse<ExchangeModel[]>;
@Injectable({
  providedIn: 'root'
})
export class StockexchangeserviceService {

  constructor(private http:HttpClient) { }

  getAllExchange():Observable<EntityResponseType>{
    
    return this.http.get<ExchangeModel[]>("http://localhost:8014/microservice1/exchanges", {observe: 'response'});
}

insertExchnage(stockexchangeModel:ExchangeModel){
   return this.http.post<ExchangeModel>("http://localhost:8014/microservice1/exchange", stockexchangeModel, {observe: 'response'});
}

}