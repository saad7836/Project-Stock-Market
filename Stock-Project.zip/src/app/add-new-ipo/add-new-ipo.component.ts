import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { IpoService } from '../ipo.service';
import { IpoModel } from 'src/entity/IpoModel';

@Component({
  selector: 'app-add-new-ipo',
  templateUrl: './add-new-ipo.component.html',
  styleUrls: ['./add-new-ipo.component.css']
})
export class AddNewIpoComponent implements OnInit {
  myForm: FormGroup;
  constructor(private service: IpoService) { }

  ngOnInit(): void {

    this.myForm = new FormGroup({
      name: new FormControl(""),
      brief: new FormControl(""),
      address: new FormControl(""),
      shares: new FormControl(""),
      remark: new FormControl("")
    });
  }
  onSubmit(form: FormGroup) {

    let ip: IpoModel = {

      company_name: form.value.name,
      stock_id: form.value.brief,
      price_per_share: form.value.address,
      no_of_shares: form.value.shares,
      remarks: form.value.remark
    }

    this.service.saveIpo(ip).subscribe(data => {
      console.log(data)
    })

  }
  notify() {
    alert("Data is Saved");
  }

}


