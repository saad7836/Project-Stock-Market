import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewIpoComponent } from './add-new-ipo.component';

describe('AddNewIpoComponent', () => {
  let component: AddNewIpoComponent;
  let fixture: ComponentFixture<AddNewIpoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNewIpoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNewIpoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
