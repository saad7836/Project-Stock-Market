import { TestBed } from '@angular/core/testing';

import { StockexchangeserviceService } from './stockexchangeservice.service';

describe('StockexchangeserviceService', () => {
  let service: StockexchangeserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StockexchangeserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
