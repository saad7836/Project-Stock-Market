import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alanding',
  templateUrl: './alanding.component.html',
  styleUrls: ['./alanding.component.css']
})
export class AlandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
