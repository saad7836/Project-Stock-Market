import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlandingComponent } from './alanding.component';

describe('AlandingComponent', () => {
  let component: AlandingComponent;
  let fixture: ComponentFixture<AlandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
