import { Component, OnInit } from '@angular/core';
import { ExcelModel } from 'src/entity/ExcelModel';
import { HttpResponse } from '@angular/common/http';
import { ExcelResponseModel } from 'src/entity/ExcelResponseModel';
import { Router } from '@angular/router';
import { UploadFileService } from '../upload-file.service';
@Component({
  selector: 'app-summary-data',
  templateUrl: './summary-data.component.html',
  styleUrls: ['./summary-data.component.css']
})

export class SummaryDataComponent implements OnInit {
  excelDetails: ExcelModel[];

  constructor(private service:UploadFileService,private router: Router) { }
  //excelsummary: ExcelResponseModel[];
  excelSumary1:ExcelResponseModel;
 
  ss: any;

  ngOnInit(): void {
    this.service.getAllDetails().subscribe(data => {
      this.excelDetails = data.body;
      console.log(data.body) 
  });


    this.service.getAllDetails1().subscribe(data => {
      this.excelSumary1 = data.body;
      console.log(data.body);
    // let ss= JSON.parse(JSON.stringify(this.excelsummary));

    });

    
  }

}

