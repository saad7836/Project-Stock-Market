import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserService } from '../user-service.service';
import { UserModel } from 'src/entity/UserModel';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  myForm:FormGroup;
  constructor(private service: UserService) { }

  ngOnInit(): void {
    this.myForm=new FormGroup({
      name: new FormControl(''),
      pass: new FormControl(''),
      Usertype: new FormControl(''),
      email: new FormControl(''),
      pnum: new FormControl(''),
    });
  }
  
  onSubmit(form: FormGroup){

    console.log('Valid?', form.valid); // true or false

    console.log(form.value.too);
    console.log(form.value.ceoname);
    let user: UserModel = {

      username: form.value.name,
      password: form.value.pass,
      userType: "user",
      email: form.value.email,
      mobile_Number: form.value.pnum,

      // confirmed:"yes",
    }
    console.log('Saving data')
    this.service.saveUser(user).subscribe(data => {
      console.log(data);
  } );
  alert("data submitted");
 }
}
