import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/entity/UserModel';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../user-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
users:UserModel[];
myForm: FormGroup;
  constructor(private service:UserService,private router:Router) { }

  ngOnInit(): void {
    this.service.getAllUsers().subscribe(data => {
      this.users=data.body;
    });

     this.myForm=new FormGroup({
       username:new FormControl('',Validators.required),
       password:new FormControl('',Validators.required)
     });
  }

  

  onSubmit(myForm:FormGroup){
    var k=0;
   
    for(var i=0;i<this.users.length;i++)
    {
      if(this.users[i].username==myForm.value.username && this.users[i].password==myForm.value.password)
      {
        k=2;
        if(this.users[i].userType== "admin")
        {
          this.router.navigate(['/admin']);
          alert("verified");
          break;
        }
        else
        {
          this.router.navigate(['/user']);
          alert("hello user!");
          break;
        }
      }
    
    }
      
       if(k==0){
        alert("invalid username or password!!!!!!!!!!!!!");
       }   
  }   
}
      
    
  
 
  


