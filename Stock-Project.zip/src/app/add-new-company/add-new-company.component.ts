import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CompanyModel } from 'src/entity/CompanyModel';
import { CompanyServiceService } from '../company-service.service';
@Component({
  selector: 'app-add-new-company',
  templateUrl: './add-new-company.component.html',
  styleUrls: ['./add-new-company.component.css']
})

export class AddNewCompanyComponent implements OnInit {
  myForm: FormGroup;
  company: CompanyModel[];
  constructor(private service: CompanyServiceService) { }

  ngOnInit(): void {
  this.myForm = new FormGroup({
    name: new FormControl(''),
    too: new FormControl(''),
    ceoname: new FormControl(''),


    bd: new FormControl(''),
    list: new FormControl(''),
    sec: new FormControl(''),
    brief: new FormControl(''),
    code: new FormControl('')

  });
  }
  notify() {

    alert("Data Updated");

  }
  onSubmit(form: FormGroup) {

    console.log('Valid?', form.valid); // true or false

    let Name = form.value.name;
    let Turnover = form.value.too;
    let Ceoname = form.value.ceoname;
    let Board = form.value.bd;
    let list = form.value.list;
    let sector = form.value.sec;
    let brief = form.value.brief;
    let code = form.value.code;
    console.log(form.value.too);
    console.log(form.value.ceoname);


    let newStudent: CompanyModel = {

      company_name: Name,
      turnover: Turnover,
      ceo: Ceoname,
      board_of_directors: Board,
      listed: list,
      sector: sector,
      write_up: brief,
      stock_code: code
    }

    console.log('Saving data')
    this.service.saveCompany(newStudent).subscribe(data => {
      console.log(data);
    });

  }
}

