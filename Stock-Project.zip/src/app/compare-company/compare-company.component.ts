import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-compare-company',
  templateUrl: './compare-company.component.html',
  styleUrls: ['./compare-company.component.css']
})

export class CompareCompanyComponent implements OnInit {

  constructor(private router:Router) { }

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels = ['june', 'july', 'august', 'sept', 'nov', 'dec'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [
    {data: [65, 59, 52, 81, 56, 55, 120], label: 'Cts'},
    {data: [28, 68, 40, 19, 86, 27, 100], label: 'Tcs'}
  ];
  ngOnInit() {
  }
  ons(){
    this.router.navigate(['/']);
  }

}