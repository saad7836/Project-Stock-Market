import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UlandingComponent } from './ulanding/ulanding.component';
import { AlandingComponent } from './alanding/alanding.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminImportComponent } from './admin-import/admin-import.component';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { AddNewCompanyComponent } from './add-new-company/add-new-company.component';
import { IPOsComponent } from './ipos/ipos.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { CompareSectorsComponent } from './compare-sectors/compare-sectors.component';
import { ReactiveFormsModule } from '@angular/forms'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UserService } from './user-service.service';
import { CompanyServiceService } from './company-service.service';
import { from } from 'rxjs';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { AddExchangeComponent } from './add-exchange/add-exchange.component';
import { AddNewIpoComponent } from './add-new-ipo/add-new-ipo.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { ChartsModule } from 'ng2-charts';
import { CompareComponent } from './compare/compare.component';
import { CompareSecComponent } from './compare-sec/compare-sec.component';
import { SummaryDataComponent } from './summary-data/summary-data.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UlandingComponent,
    AlandingComponent,
    SignUpComponent,
    AdminImportComponent,
    ManageCompanyComponent,
    AddNewCompanyComponent,
    IPOsComponent,
    CompareCompanyComponent,
    CompareSectorsComponent,
    ManageExchangeComponent,
    AddExchangeComponent,
    AddNewIpoComponent,
    NavBarComponent,
    CompareComponent,
    CompareSecComponent,
    SummaryDataComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    ChartsModule
    
  ],
  providers: [UserService , CompanyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
