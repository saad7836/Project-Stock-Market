import { Component, OnInit } from '@angular/core';
import { IpoService } from '../ipo.service';
import { IpoModel } from 'src/entity/IpoModel';

@Component({
  selector: 'app-ulanding',
  templateUrl: './ulanding.component.html',
  styleUrls: ['./ulanding.component.css']
})
export class UlandingComponent implements OnInit {

  

  ipo:IpoModel[];
      constructor(private service:IpoService) { }
  
      ngOnInit(): void {
    this.service.getAll().subscribe(data =>{
    this.ipo=data.body;
  
    });
      }
}
