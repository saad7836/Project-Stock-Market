import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ExchangeModel } from 'src/entity/ExchangeModel';
import { StockexchangeserviceService } from '../stockexchangeservice.service';
@Component({
  selector: 'app-manage-exchange',
  templateUrl: './manage-exchange.component.html',
  styleUrls: ['./manage-exchange.component.css']
})
export class ManageExchangeComponent implements OnInit {
  stockForm: FormGroup;
  stock1:ExchangeModel[];
  constructor(private stockservice:StockexchangeserviceService,private router:Router) { }

  ngOnInit(): void {
    this.stockservice.getAllExchange().subscribe(data => {
      this.stock1 = data.body;
      console.log(data.body);
  } );

  {

    this.stockForm = new FormGroup({
      stock_exchange: new FormControl(''),
      brief: new FormControl(''),
      contact_address: new FormControl(''),
      remarks: new FormControl('')
  
  });

}
  }

  onSubmit(stockForm:FormGroup){

    let stock2:ExchangeModel={
      id:0,
      
      stock_exchange:stockForm.value.stock_exchange ,
      brief:stockForm.value.brief ,
      contact_address:stockForm.value.contact_address,
      remarks:stockForm.value.remarks
      
    }
  
    this.stockservice.insertExchnage(stock2).subscribe(data =>{console.log(data.body)});
    this.router.navigate(['/exchange'])
  
  }
  
}





