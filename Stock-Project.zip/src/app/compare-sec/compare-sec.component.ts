import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-sec',
  templateUrl: './compare-sec.component.html',
  styleUrls: ['./compare-sec.component.css']
})
export class CompareSecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
