import { Component, OnInit } from '@angular/core';
import {CompanyModel } from 'src/entity/CompanyModel';
import { CompanyServiceService } from '../company-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-company',
  templateUrl: './manage-company.component.html',
  styleUrls: ['./manage-company.component.css']
})

  
export class ManageCompanyComponent implements OnInit {

  company:CompanyModel[];
  company1:any;

  constructor(private companyservice:CompanyServiceService, private router:Router) { }

  ngOnInit(): void {
    this.companyservice.getAllCompany().subscribe(data => {
         this.company = data.body;
         console.log(data.body)
    });
  }

    updateCompany(id:number){
      this.router.navigate(['/updatecompany',id]);

    }
    deleteCompany(id:number){
      console.log(id);
      this.companyservice.deleteCompany(id).subscribe(data => this.company1=data);
    }
    
}





