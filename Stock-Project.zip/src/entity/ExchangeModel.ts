export interface ExchangeModel{
    id?:number;
    stock_exchange:string;
    brief:string ;
    contact_address:string;
    remarks:string;
}