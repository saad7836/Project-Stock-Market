export interface CompanyModel{
    id?:number;
    company_name:string;
    turnover:string;
    ceo:string;
    board_of_directors:string;
    listed:string;
    sector:string;
    write_up:string;
    stock_code:number;
}