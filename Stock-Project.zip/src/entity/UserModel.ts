export interface UserModel{
    id?:number;
    username:string;
    password:string;
    userType?:string;
    email:string;
    mobile_Number:string;
    confirmed?:string;
}