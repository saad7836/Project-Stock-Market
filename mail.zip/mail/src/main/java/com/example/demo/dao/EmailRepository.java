package com.example.demo.dao;

public class EmailRepository {

}
