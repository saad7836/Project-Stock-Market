package com.vp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "UserDB")
public class User {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String Username;
	
	private String Password;

	private String UserType;
	
	private String Email;
	
	private String Mobile_Number;
	
	private String Confirmed;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getUserType() {
		return UserType;
	}

	public void setUserType(String userType) {
		UserType = userType;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getMobile_Number() {
		return Mobile_Number;
	}

	public void setMobile_Number(String mobile_Number) {
		Mobile_Number = mobile_Number;
	}

	public String getConfirmed() {
		return Confirmed;
	}

	public void setConfirmed(String confirmed) {
		Confirmed = confirmed;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", Username=" + Username + ", Password=" + Password + ", UserType=" + UserType
				+ ", Email=" + Email + ", Mobile_Number=" + Mobile_Number + ", Confirmed=" + Confirmed + "]";
	}

	public User(int id, String username, String password, String userType, String email, String mobile_Number,
			String confirmed) {
		super();
		this.id = id;
		Username = username;
		Password = password;
		UserType = userType;
		Email = email;
		Mobile_Number = mobile_Number;
		Confirmed = confirmed;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
