package com.vp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IPO")
public class Ipo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private String company_name;
	private Long stock_id;
	private Long price_per_share;
	private Long no_of_shares;
	private String remarks;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public Long getStock_id() {
		return stock_id;
	}
	public void setStock_id(Long stock_id) {
		this.stock_id = stock_id;
	}
	public Long getPrice_per_share() {
		return price_per_share;
	}
	public void setPrice_per_share(Long price_per_share) {
		this.price_per_share = price_per_share;
	}
	public Long getNo_of_shares() {
		return no_of_shares;
	}
	public void setNo_of_shares(Long no_of_shares) {
		this.no_of_shares = no_of_shares;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Ipo(Long id, String company_name, Long stock_id, Long price_per_share, Long no_of_shares, String remarks) {
		super();
		this.id = id;
		this.company_name = company_name;
		this.stock_id = stock_id;
		this.price_per_share = price_per_share;
		this.no_of_shares = no_of_shares;
		this.remarks = remarks;
	}
	public Ipo() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Ipo [id=" + id + ", company_name=" + company_name + ", stock_id=" + stock_id + ", price_per_share="
				+ price_per_share + ", no_of_shares=" + no_of_shares + ", remarks=" + remarks + "]";
	}
	
	
}
