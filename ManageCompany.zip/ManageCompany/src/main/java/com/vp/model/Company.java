package com.vp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "company")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String company_name;
	
	private String turnover;

	private String ceo;
	
	private String board_of_directors;
	
	private String listed;
	
	private String sector;
	
	private String write_up;
	
	private int stock_code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getTurnover() {
		return turnover;
	}

	public void setTurnover(String turnover) {
		this.turnover = turnover;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoard_of_directors() {
		return board_of_directors;
	}

	public void setBoard_of_directors(String board_of_directors) {
		this.board_of_directors = board_of_directors;
	}

	public String getListed() {
		return listed;
	}

	public void setListed(String listed) {
		this.listed = listed;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getWrite_up() {
		return write_up;
	}

	public void setWrite_up(String write_up) {
		this.write_up = write_up;
	}

	public int getStock_code() {
		return stock_code;
	}

	public void setStock_code(int stock_code) {
		this.stock_code = stock_code;
	}

	public Company(Long id, String company_name, String turnover, String ceo, String board_of_directors, String listed,
			String sector, String write_up, int stock_code) {
		super();
		this.id = id;
		this.company_name = company_name;
		this.turnover = turnover;
		this.ceo = ceo;
		this.board_of_directors = board_of_directors;
		this.listed = listed;
		this.sector = sector;
		this.write_up = write_up;
		this.stock_code = stock_code;
	}

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", company_name=" + company_name + ", turnover=" + turnover + ", ceo=" + ceo
				+ ", board_of_directors=" + board_of_directors + ", listed=" + listed + ", sector=" + sector
				+ ", write_up=" + write_up + ", stock_code=" + stock_code + "]";
	}
	
	
}
