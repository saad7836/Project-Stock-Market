package com.vp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}





//public class ManageApplicationTests {
	//@BeforeClass
	//static public void beforeClass() {
		//System.out.println("beforeClass");
	//}
	
	//@Before
	//public void beforeTest() {
		//System.out.println("Before");
	//}
	
	//@Test
	//public void testAdd() {
		//System.out.println("in test testAdd");
		//assertEquals(300, JunitLogic.add(100, 200));
	//}
	
	//@Test
	//public void testCube() {
		//assertEquals(8, JunitLogic.cube(2));
	//}
	
	//@After
	//public void afterTest() {
		//System.out.println("afterTest");
	//}
	
	//@AfterClass
	//static public void afterClass(){
		//System.out.println("afterClass ... ");
	//}
//}



